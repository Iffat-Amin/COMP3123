import React from 'react'

function Welcome(){
    return <h1>Welcome</h1>
     
}



 export function Greet() {
  return (
    <h3>I am a default component</h3>
  )
}


export default Welcome;